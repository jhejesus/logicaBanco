<?php
include('conexao.php');
session_start();
    // Verifica se o formulário foi submetido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtém dados do formulário
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    }

    // Query de inserção usando declaração preparada
    $sql = "INSERT INTO usuarios (username, email, password, confirmPassword) VALUES ('$username', '$email', '$password', '$confirmPassword')";

    if ($conn->query($sql) === TRUE) {
        $last_id = $conn->insert_id;
        echo "usuario inserido com sucesso, seu numero de inserssão é: " . $last_id;
        header('location:index.html');
      } else {
        header('location:index.html');
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
      $_SESSION['email'] = $email;
      $conn->close();
      ?>
