<?php
include('conexao.php');
session_start();

// Função para adicionar compra
function adicionarCompra($usuario_id, $data, $total, $itens) {
    global $conn;
    $sql = "INSERT INTO Compras (usuario_id, data, total) VALUES ($usuario_id, '$data', $total)";
    if ($conn->query($sql) === TRUE) {
        $compra_id = $conn->insert_id; // Obter o ID da compra inserida
        // Inserir itens da compra
        foreach ($itens as $item) {
            $produto_id = $item['produto_id'];
            $cor = $item['cor'];
            $tamanho = $item['tamanho'];
            $quantidade = $item['quantidade'];
            $preco_unitario = $item['preco_unitario'];
            $sql = "INSERT INTO Itens_Compra (compra_id, produto_id, cor, tamanho, quantidade, preco_unitario) VALUES ($compra_id, $produto_id, '$cor', '$tamanho', $quantidade, $preco_unitario)";
            if ($conn->query($sql) !== TRUE) {
                echo "Erro ao adicionar itens da compra: " . $conn->error;
            }
        }
        echo "Compra adicionada com sucesso!";
    } else {
        echo "Erro ao adicionar compra: " . $conn->error;
    }
}
// Para ter certeza que irá chamar a cor que o ususario selecionar
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cor_selecionada = $_POST["cor"];
}

// Exemplo de como seria,(só pra eu não me perder na logica sksk)
$usuario_id = 1;
$data = "2024-05-07";
$total = 89.97;
$itens = array(
    array("produto_id" => 1, "cor" => "Azul", "tamanho" => "M", "quantidade" => 2, "preco_unitario" => 29.99),
    array("produto_id" => 1, "cor" => "Vermelho", "tamanho" => "L", "quantidade" => 1, "preco_unitario" => 29.99)
);
adicionarCompra($usuario_id, $data, $total, $itens);

// Fechar conexão com o banco de dados
$conn->close();
?>